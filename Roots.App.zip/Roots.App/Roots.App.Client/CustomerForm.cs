﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net.Http;
using Roots.App.Models;
using System.Configuration;

namespace Roots.App.Client
{
    public partial class CustomerForm : Form
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            HttpClient httpClient = new HttpClient();

            Customer customer = new Customer();
            customer.CustomerName = txtName.Text;
            customer.Email = txtEmail.Text;

            HttpResponseMessage response = httpClient.PostAsJsonAsync(ConfigurationManager.AppSettings["BaseUrlApi"].ToString() + "Customer",customer).Result;

            if (response.IsSuccessStatusCode)
            {
                //Customer result = response.Content.ReadAsAsync<Customer>().Result;
                var result = response.Content.ReadAsStringAsync().Result;
                MessageBox.Show(result);
                GetCustomers();
            }

        }

        private void frmCustomer_Load(object sender, EventArgs e)
        {
            GetCustomers();
        }

        private void GetCustomers(){
            HttpClient httpClient = new HttpClient();
            HttpResponseMessage response = httpClient.GetAsync(ConfigurationManager.AppSettings["BaseUrlApi"].ToString() + "Customer").Result;

            if (response.IsSuccessStatusCode) {
                IEnumerable<Customer> result = response.Content.ReadAsAsync<IEnumerable<Customer>>().Result;
                dgCustomers.DataSource = result;
            }
        }
    }
}
