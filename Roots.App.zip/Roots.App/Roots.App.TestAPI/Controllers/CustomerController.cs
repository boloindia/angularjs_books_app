﻿using Roots.App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using System.Data.SqlClient;
namespace Roots.App.TestAPI.Controllers
{
    public class CustomerController : ApiController
    {
        //List<Customer> customers = new List<Customer>(){
        //    new Customer(){Id = 1, CustomerName= "Gaurav Madaan", Email="gauravmadaan@outlook.com"}
        //};

        public IHttpActionResult GetCustomers()
        {
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["CustomerDBConnection"].ToString());
            SqlCommand command = new SqlCommand("Select * From Customer", connection);
            List<Customer> customers = new List<Customer>();
            try
            {
                connection.Open();
                command.CommandType = System.Data.CommandType.Text;
                var reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Customer customer = new Customer();
                        customer.Id = Convert.ToInt32(reader.GetValue(0));
                        customer.CustomerName = Convert.ToString(reader.GetValue(1));
                        customer.Email = Convert.ToString(reader.GetValue(2));
                        
                        customers.Add(customer);
                    }
                }

                connection.Close();
                return Ok(customers);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IHttpActionResult AddCustomer(Customer customer)
        {
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["CustomerDBConnection"].ToString());
            SqlCommand command = new SqlCommand("Insert into Customer(CustomerName,Email) Values('" + customer.CustomerName + "','" + customer.Email + "')", connection);
            try
            {
                connection.Open();
                command.CommandType = System.Data.CommandType.Text;
                command.ExecuteNonQuery();
                connection.Close();
                return Ok("Customer Added Successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPut]
        public IHttpActionResult UpdateCustomer(Customer customer)
        {
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["CustomerDBConnection"].ToString());
            SqlCommand command = new SqlCommand("Update Customer set CustomerName= '" + customer.CustomerName + "',Email='" + customer.Email + "' Where Id=" + customer.Id, connection);
            try
            {
                connection.Open();
                command.CommandType = System.Data.CommandType.Text;
                command.ExecuteNonQuery();
                connection.Close();
                return Ok("Customer Updated Successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
    }
}
